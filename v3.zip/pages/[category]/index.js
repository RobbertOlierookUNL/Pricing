import React from "react";
import DashboardPickApp from "../../components/DashboardPickApp";

const DashboardPickPage = () => {
	return (
		<DashboardPickApp/>
	);
};


export default DashboardPickPage;
