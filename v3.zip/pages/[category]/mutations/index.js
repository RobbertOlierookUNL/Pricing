import React from "react";


import MutationDashboard from "../../../components/dashboards/MutationDashboard";


const MutationDashboardPage = () => {
	return (
		<MutationDashboard/>
	);
};


export default MutationDashboardPage;
