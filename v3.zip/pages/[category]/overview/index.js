import React from "react";


import PlanDashboard from "../../../components/dashboards/PlanDashboard";


const PlanDashboardPage = () => {
	return (
		<PlanDashboard/>
	);
};


export default PlanDashboardPage;
