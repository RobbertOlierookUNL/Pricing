
import {
	getAllDetailedProducts,
	getAllProducts,
	getCategories,
	getCategoryInfo,
	getMeasurements,
	getRetailers
} from "../../../util/api-functions/queries";
import {
	getCodes,
	getMutationsFromMeasurements,
	getRetailerMap
} from "../../../util/api-functions/query-helpers";
import { getDateStringFromValue } from "../../../lib/config";
import getDateStrings from "../../../util/api-functions/get-date-strings";










const handler = async (req, res) => {
	const {category, interval} = req.query;
	const i = getDateStringFromValue(interval);
	console.log({interval, i});
	try {

		if (req.method === "GET") {
			const {[i]: intervalDate, todayString } = getDateStrings();

			console.log(0);
			const categories = await getCategories(category);
			console.log({categories});

			const categoryInfo = await getCategoryInfo(category);
			console.log(1);
			const products = await getAllDetailedProducts(categories, categoryInfo);
			console.log(2);
			const {eans, eanToDescription} = getCodes(products);
			console.log({products, eans});
			console.log(3);
			const measurements = await getMeasurements(eans, {intervalDate, todayString});
			const retailers = await getRetailers(category);
			const retailerMap = getRetailerMap(retailers);
			console.log(4);
			const mutations = getMutationsFromMeasurements(measurements, eanToDescription, {intervalDate, todayString}, categoryInfo, retailerMap);

			return res.json(mutations);
		} else {
			res.status(400).json({ message: `Does not support a ${req.method} request` });
		}
	} catch (e) {

		res.status(500).json({ message: e.message});
	}

};

export default handler;
