import React from "react";
import CategoryPickApp from "../components/CategoryPickApp";

const Home = () => {

	return (
		<CategoryPickApp/>
	);
};


export default Home;
