import { allBrandsText } from "../lib/config";
import {
	useBrandsFromCategory,
	useCategoriesFromCategory,
	useConceptsFromBrand,
	useDataFromConcept,
	useMutations,
} from "./useSwr-hooks";
import useConfig from "./useConfig";
import usePrefetcher from "./usePrefetcher";

const usePrefetchCategory = category => {
	const {categories, categoriesIsLoading} = useCategoriesFromCategory(category);
	const {brands, brandsIsLoading} = useBrandsFromCategory(categories, category);
	const defaultBrand = brands?.[0];
	const brand = defaultBrand;
	const {concepts, conceptsIsLoading} = useConceptsFromBrand(categories, brand, category);
	const defaultConcept = brand === allBrandsText ? allBrandsText : concepts?.[0];
	const concept = defaultConcept;
	const {data, dataIsLoading} = useDataFromConcept(categories, brand, concept, category);
	const [intervalMode] = useConfig("intervalMode");
	useMutations(category, intervalMode);
	console.log({data});
	const loadingState = categoriesIsLoading || brandsIsLoading || conceptsIsLoading || dataIsLoading;
	usePrefetcher(loadingState, categories, brand, concept, brands, concepts, data, category);


};

export default usePrefetchCategory;
