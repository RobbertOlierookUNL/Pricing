import React from "react";

const Settings = ({children}) => {
	return (
		<div>{children}
			<style jsx>{`
      background-color: white;
    `}</style>
		</div>
	);
};



export default Settings;
