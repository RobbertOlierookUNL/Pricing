import React from "react";

import AdvicesApp from "../../components/AdvicesApp";


const AdvicesPage = () => {
	return (
		<AdvicesApp/>
	);
};



export default AdvicesPage;
