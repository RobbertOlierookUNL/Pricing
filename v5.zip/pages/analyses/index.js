import React from "react";

const AnalysesPage = () => {
	return (
		<div>Work in progress</div>
	);
};



export default AnalysesPage;
