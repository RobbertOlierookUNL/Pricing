import React from "react";

// import { getAdvicePrices } from "../util/functions";


const dev = () => {
	// console.log(getAdvicePrices([10, 9.82, 9.79], [9.41, 9.39, 9.54], 12.99, 12.49));

	return (
		<div>
			<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
				<circle cx="50" cy="50" r="50"/>
			</svg>
		</div>
	);
};



export default dev;
