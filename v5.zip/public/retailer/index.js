import React from "react";


import RetailerDashboard from "../../../components/dashboards/RetailerDashboard";


const RetailerDashboardPage = () => {
	return (
		<RetailerDashboard/>
	);
};


export default RetailerDashboardPage;
